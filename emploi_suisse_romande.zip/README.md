# 🇨🇭 Emploi Romand - SaaS de Recherche d'Emploi

> Application SaaS ultra-automatisée dédiée exclusivement à la recherche d'emploi en Suisse Romande

[![React](https://img.shields.io/badge/React-18.3.1-blue.svg)](https://reactjs.org/)
[![TypeScript](https://img.shields.io/badge/TypeScript-5.5.3-blue.svg)](https://www.typescriptlang.org/)
[![Supabase](https://img.shields.io/badge/Supabase-2.55.0-green.svg)](https://supabase.com/)
[![Tailwind CSS](https://img.shields.io/badge/Tailwind_CSS-3.4.11-38B2AC.svg)](https://tailwindcss.com/)

## 🌟 **Aperçu**

Emploi Romand est une plateforme SaaS révolutionnaire qui automatise entièrement votre recherche d'emploi en Suisse Romande. Grâce à l'intelligence artificielle, aux tests psychométriques avancés et à un système de suivi Kanban intuitif, maximisez vos chances de décrocher l'emploi de vos rêves.

### 🎯 **Fonctionnalités Principales**

- **🤖 Recherche Automatisée** - IA qui scanne et filtre les offres d'emploi
- **📝 Génération de CV/Lettres** - Personnalisation automatique pour chaque offre
- **📊 Suivi Kanban** - Tableau de bord drag & drop pour vos candidatures
- **🧠 Tests Psychométriques** - RIASEC et Ennéagramme pour l'orientation
- **🎤 Préparation Entretiens** - Assistant IA avec chat vocal
- **📈 Analytics Avancés** - Statistiques et recommandations personnalisées

## 🚀 **Démo en Ligne**

**🔗 [Accéder à l'application](https://k9h2wf5a9h.skywork.website)**

### 👤 **Comptes de Test**
- **Email :** demo@emploiromand.ch
- **Mot de passe :** Demo123!

## 📋 **Table des Matières**

- [Installation](#-installation)
- [Configuration](#-configuration)
- [Utilisation](#-utilisation)
- [Architecture](#-architecture)
- [API Documentation](#-api-documentation)
- [Déploiement](#-déploiement)
- [Contribution](#-contribution)
- [Support](#-support)

## 🛠️ **Installation**

### **Prérequis**

- Node.js 18+ 
- npm ou yarn
- Compte Supabase (gratuit)

### **Installation Rapide**

```bash
# 1. Cloner le repository
git clone https://github.com/votre-username/emploi-suisse-romande.git
cd emploi-suisse-romande

# 2. Installer les dépendances
npm install

# 3. Configurer les variables d'environnement
cp .env.example .env.local
# Éditer .env.local avec vos clés Supabase

# 4. Initialiser la base de données
npm run db:setup

# 5. Lancer en développement
npm run dev
```

L'application sera accessible sur `http://localhost:5173`

## ⚙️ **Configuration**

### **Variables d'Environnement**

Créez un fichier `.env.local` à la racine du projet :

```env
# Supabase Configuration
VITE_SUPABASE_URL=votre_supabase_url
VITE_SUPABASE_ANON_KEY=votre_supabase_anon_key

# Optional: Third-party APIs
VITE_OPENAI_API_KEY=votre_openai_key
VITE_RESEND_API_KEY=votre_resend_key
```

### **Configuration Supabase**

1. **Créer un projet Supabase :**
   - Allez sur [supabase.com](https://supabase.com)
   - Créez un nouveau projet
   - Notez l'URL et la clé anonyme

2. **Exécuter les migrations :**
   ```bash
   # Depuis le dossier supabase/
   supabase db reset
   ```

3. **Configurer l'authentification :**
   - Activez l'authentification par email
   - Configurez les redirections d'URL

## 🎯 **Utilisation**

### **Pour les Candidats**

1. **Inscription/Connexion**
   - Créez votre compte avec email/mot de passe
   - Complétez votre profil professionnel

2. **Tests Psychométriques**
   - Passez le test RIASEC (10-15 min)
   - Complétez l'Ennéagramme (15-20 min)
   - Obtenez vos recommandations de carrière

3. **Recherche d'Emploi**
   - Configurez vos critères de recherche
   - Laissez l'IA trouver les meilleures offres
   - Postulez en un clic avec CV/lettre générés

4. **Suivi des Candidatures**
   - Utilisez le tableau Kanban pour suivre vos candidatures
   - Ajoutez des notes et dates d'entretien
   - Analysez vos statistiques de réussite

5. **Préparation aux Entretiens**
   - Entraînez-vous avec l'assistant IA
   - Consultez les ressources spécialisées
   - Pratiquez avec le chat vocal

### **Pour les Administrateurs**

1. **Gestion des Offres**
   - Import automatique via APIs
   - Modération et validation
   - Configuration des sources

2. **Analytics**
   - Tableau de bord des métriques
   - Rapports d'utilisation
   - Optimisation des algorithmes

## 🏗️ **Architecture**

### **Stack Technique**

```
Frontend (React + TypeScript)
├── Vite (Build tool)
├── Tailwind CSS (Styling)
├── shadcn/ui (Components)
├── React Router (Navigation)
├── Recharts (Analytics)
└── @hello-pangea/dnd (Drag & Drop)

Backend (Supabase)
├── PostgreSQL (Database)
├── Row Level Security (RLS)
├── Supabase Auth (Authentication)
├── Supabase Storage (Files)
└── Edge Functions (API)

External APIs
├── OpenAI (IA Conversationnelle)
├── Resend (Emails)
└── N8N (Automatisation)
```

### **Structure du Projet**

```
emploi-suisse-romande/
├── src/
│   ├── components/          # Composants réutilisables
│   │   ├── layout/         # Layout et navigation
│   │   └── ui/             # Composants UI de base
│   ├── pages/              # Pages de l'application
│   ├── contexts/           # Contextes React (Auth, etc.)
│   ├── hooks/              # Hooks personnalisés
│   ├── types/              # Types TypeScript
│   ├── lib/                # Utilitaires et helpers
│   └── integrations/       # Intégrations externes
├── supabase/
│   ├── migrations/         # Migrations SQL
│   └── edge_function/      # Fonctions Edge
├── public/                 # Assets statiques
└── docs/                   # Documentation
```

## 📊 **Base de Données**

### **Schéma Principal**

```sql
-- Utilisateurs et profils
user_profiles (id, email, first_name, last_name, ...)

-- Offres d'emploi
job_offers (id, title, company_name, description, ...)

-- Candidatures avec statuts Kanban
applications (id, user_id, job_offer_id, status, ...)

-- Tests psychométriques
riasec_tests (id, question_text, category, ...)
riasec_results (id, user_id, scores, dominant_type, ...)
enneagram_tests (id, question_text, type_weights, ...)
enneagram_results (id, user_id, scores, dominant_type, ...)

-- Données de référence Suisse
cantons (id, code, name)
communes (id, canton_id, name, postal_code, bfs_number)
sectors (id, parent_id, noga_code, name, level)
```

### **Sécurité RLS**

Toutes les tables sensibles sont protégées par Row Level Security :

```sql
-- Exemple : Les utilisateurs ne voient que leurs propres données
CREATE POLICY "Users can view own data" ON applications
    FOR SELECT USING (auth.uid() = user_id);
```

## 🔌 **API Documentation**

### **Endpoints Principaux**

#### **Authentification**
```typescript
// Inscription
POST /auth/signup
{
  email: string,
  password: string,
  userData: UserProfile
}

// Connexion  
POST /auth/signin
{
  email: string,
  password: string
}
```

#### **Recherche d'Emploi**
```typescript
// Rechercher des offres
GET /api/jobs?canton=GE&sector=IT&salary_min=80000

// Postuler à une offre
POST /api/applications
{
  job_offer_id: string,
  auto_generate: boolean
}
```

#### **Tests Psychométriques**
```typescript
// Soumettre un test RIASEC
POST /api/riasec/submit
{
  answers: { question_id: string, score: number }[]
}

// Obtenir les résultats
GET /api/riasec/results/:user_id
```

## 🚀 **Déploiement**

### **Déploiement Vercel (Recommandé)**

```bash
# 1. Installer Vercel CLI
npm i -g vercel

# 2. Déployer
vercel --prod

# 3. Configurer les variables d'environnement
vercel env add VITE_SUPABASE_URL
vercel env add VITE_SUPABASE_ANON_KEY
```

### **Déploiement Netlify**

```bash
# 1. Build de production
npm run build

# 2. Déployer le dossier dist/
netlify deploy --prod --dir=dist
```

### **Déploiement Docker**

```dockerfile
FROM node:18-alpine
WORKDIR /app
COPY package*.json ./
RUN npm ci --only=production
COPY . .
RUN npm run build
EXPOSE 3000
CMD ["npm", "run", "preview"]
```

## 🧪 **Tests**

```bash
# Tests unitaires
npm run test

# Tests d'intégration
npm run test:integration

# Tests E2E
npm run test:e2e

# Coverage
npm run test:coverage
```

## 📈 **Performance**

### **Métriques Cibles**

- **First Contentful Paint :** < 1.5s
- **Largest Contentful Paint :** < 2.5s
- **Cumulative Layout Shift :** < 0.1
- **Time to Interactive :** < 3.5s

### **Optimisations Implémentées**

- ✅ Code splitting automatique
- ✅ Lazy loading des composants
- ✅ Optimisation des images
- ✅ Compression gzip/brotli
- ✅ Cache intelligent
- ✅ Préchargement des ressources critiques

## 🔒 **Sécurité**

### **Mesures Implémentées**

- ✅ **Authentification JWT** avec Supabase
- ✅ **Row Level Security (RLS)** sur toutes les tables
- ✅ **Validation côté client et serveur**
- ✅ **Protection CORS** configurée
- ✅ **Chiffrement des données sensibles**
- ✅ **Rate limiting** sur les APIs
- ✅ **Audit logs** des actions utilisateur

## 🌍 **Internationalisation**

Support multilingue prévu :
- 🇫🇷 Français (par défaut)
- 🇩🇪 Allemand
- 🇮🇹 Italien
- 🇬🇧 Anglais

## 📱 **Responsive Design**

Optimisé pour tous les appareils :
- 📱 **Mobile** (320px+)
- 📱 **Tablette** (768px+)
- 💻 **Desktop** (1024px+)
- 🖥️ **Large Desktop** (1440px+)

## 🤝 **Contribution**

### **Comment Contribuer**

1. **Fork** le projet
2. **Créez** une branche feature (`git checkout -b feature/AmazingFeature`)
3. **Committez** vos changements (`git commit -m 'Add AmazingFeature'`)
4. **Push** vers la branche (`git push origin feature/AmazingFeature`)
5. **Ouvrez** une Pull Request

### **Standards de Code**

- **ESLint** + **Prettier** pour le formatage
- **Conventional Commits** pour les messages
- **Tests** obligatoires pour les nouvelles fonctionnalités
- **Documentation** mise à jour

### **Roadmap**

- [ ] **Q1 2025 :** Application mobile (React Native)
- [ ] **Q2 2025 :** Intégration LinkedIn avancée
- [ ] **Q3 2025 :** IA générative pour CV/lettres
- [ ] **Q4 2025 :** Marketplace de services RH

## 📞 **Support**

### **Canaux de Support**

- 📧 **Email :** support@emploiromand.ch
- 💬 **Discord :** [Rejoindre la communauté](https://discord.gg/emploiromand)
- 📖 **Documentation :** [docs.emploiromand.ch](https://docs.emploiromand.ch)
- 🐛 **Issues GitHub :** [Signaler un bug](https://github.com/votre-username/emploi-suisse-romande/issues)

### **FAQ**

**Q : L'application est-elle gratuite ?**
R : Oui, version freemium avec fonctionnalités de base gratuites.

**Q : Mes données sont-elles sécurisées ?**
R : Absolument. Chiffrement end-to-end et conformité RGPD.

**Q : Puis-je utiliser l'app hors Suisse Romande ?**
R : L'app est optimisée pour la Suisse Romande mais adaptable.

## 📄 **Licence**

Ce projet est sous licence MIT. Voir le fichier [LICENSE](LICENSE) pour plus de détails.

## 🙏 **Remerciements**

- **Supabase** pour l'infrastructure backend
- **Vercel** pour l'hébergement
- **shadcn/ui** pour les composants UI
- **Communauté Open Source** pour les outils utilisés

---

<div align="center">

**Fait avec ❤️ en Suisse Romande**

[🌐 Site Web](https://emploiromand.ch) • [📧 Contact](mailto:contact@emploiromand.ch) • [🐦 Twitter](https://twitter.com/emploiromand)

</div>